"""POST /audit — hallucination check on a coaching response."""
from __future__ import annotations

from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException, Request, status
from sqlalchemy.ext.asyncio import AsyncSession

from app.audit import audit_response
from app.auth import require_user
from app.db import get_session
from app.schemas import AuditBody, AuditResponse, ErrorResponse

router = APIRouter(tags=["Audit"])


@router.post(
    "/audit",
    response_model=AuditResponse,
    responses={401: {"model": ErrorResponse}, 403: {"model": ErrorResponse}},
)
async def post_audit(
    request: Request,
    body: AuditBody,
    db: Annotated[AsyncSession, Depends(get_session)],
    jwt_sub: Annotated[str, Depends(require_user)],
) -> AuditResponse:
    if body.userId != jwt_sub:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={
                "error": "FORBIDDEN",
                "message": "Cross-tenant access denied.",
                "traceId": getattr(request.state, "trace_id", ""),
            },
        )
    return await audit_response(db, body)
