"""GET /users/{userId}/profile — evidence-cited behavioral profile."""
from __future__ import annotations

from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException, Path, Request, status

from app.auth import require_user_match
from app.profile import build_profile
from app.schemas import BehavioralProfile, ErrorResponse

router = APIRouter(prefix="/users", tags=["Users"])


@router.get(
    "/{userId}/profile",
    response_model=BehavioralProfile,
    responses={
        401: {"model": ErrorResponse},
        403: {"model": ErrorResponse},
        404: {"model": ErrorResponse},
    },
)
async def get_profile(
    request: Request,
    userId: Annotated[str, Path()],
    _: Annotated[str, Depends(require_user_match("userId"))],
) -> BehavioralProfile:
    profile = build_profile(userId)
    if profile is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={
                "error": "USER_NOT_FOUND",
                "message": f"No seed profile for user {userId}.",
                "traceId": getattr(request.state, "trace_id", ""),
            },
        )
    return profile
