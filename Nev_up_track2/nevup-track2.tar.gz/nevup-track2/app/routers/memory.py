"""Memory contract — `/memory/{userId}/...`

Three endpoints, exactly as specified in the deck. Every endpoint enforces
row-level tenancy via `require_user_match("userId")` so a token issued for
user A can never read user B's memories. Cross-tenant returns 403 — never 404.
"""
from __future__ import annotations

from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException, Path, Query, Request, status
from sqlalchemy.ext.asyncio import AsyncSession

from app.auth import require_user_match
from app.db import get_session
from app.memory import get_context, get_session_memory, put_session_memory
from app.schemas import (
    ContextResponse,
    ErrorResponse,
    MemoryWriteBody,
    SessionSummaryRecord,
)

router = APIRouter(prefix="/memory", tags=["Memory"])


@router.put(
    "/{userId}/sessions/{sessionId}",
    response_model=SessionSummaryRecord,
    responses={401: {"model": ErrorResponse}, 403: {"model": ErrorResponse}},
)
async def put_memory(
    request: Request,
    body: MemoryWriteBody,
    userId: Annotated[str, Path()],
    sessionId: Annotated[str, Path()],
    db: Annotated[AsyncSession, Depends(get_session)],
    _: Annotated[str, Depends(require_user_match("userId"))],
) -> SessionSummaryRecord:
    """Persist a session summary. Idempotent on (userId, sessionId)."""
    return await put_session_memory(
        db, user_id=userId, session_id=sessionId, body=body
    )


@router.get(
    "/{userId}/context",
    response_model=ContextResponse,
    responses={401: {"model": ErrorResponse}, 403: {"model": ErrorResponse}},
)
async def get_memory_context(
    request: Request,
    userId: Annotated[str, Path()],
    relevantTo: Annotated[str, Query(min_length=1, max_length=400)],
    db: Annotated[AsyncSession, Depends(get_session)],
    _: Annotated[str, Depends(require_user_match("userId"))],
    limit: Annotated[int, Query(ge=1, le=20)] = 5,
) -> ContextResponse:
    """Retrieve session memories most relevant to a signal."""
    sessions, pattern_ids = await get_context(
        db, user_id=userId, relevant_to=relevantTo, limit=limit
    )
    return ContextResponse(sessions=sessions, patternIds=pattern_ids)


@router.get(
    "/{userId}/sessions/{sessionId}",
    response_model=SessionSummaryRecord,
    responses={
        401: {"model": ErrorResponse},
        403: {"model": ErrorResponse},
        404: {"model": ErrorResponse},
    },
)
async def get_memory_session(
    request: Request,
    userId: Annotated[str, Path()],
    sessionId: Annotated[str, Path()],
    db: Annotated[AsyncSession, Depends(get_session)],
    _: Annotated[str, Depends(require_user_match("userId"))],
) -> SessionSummaryRecord:
    """Retrieve the exact stored session record. Used for hallucination audit."""
    rec = await get_session_memory(db, user_id=userId, session_id=sessionId)
    if rec is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={
                "error": "MEMORY_NOT_FOUND",
                "message": f"No memory found for session {sessionId}.",
                "traceId": getattr(request.state, "trace_id", ""),
            },
        )
    return rec
